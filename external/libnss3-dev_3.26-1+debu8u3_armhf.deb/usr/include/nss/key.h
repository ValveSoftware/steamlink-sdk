/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* This header is deprecated.  Please include keyhi.h instead. */

#ifndef _KEY_H_
#define _KEY_H_

#include "keyhi.h"

#endif /* _KEY_H_ */
